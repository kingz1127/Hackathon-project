Retrieval For COD2 by Etromania - etromania@wclan.com - www.wclan.com
This is not a port of RE but a recreation Combining SD and CTF Gametypes 

** Request for Other developers **

I am requesting that other dev's and modders not change RE but to work with me 
as a group to have a community standard for the RE gametype . 
If changes are requested and done 
a community update will be made for all 

This way there is one version of Retrieval , and not many variants 

***********************************

In light of COD2 being a Sequal, in RE for COD2 the Germans Must retrieve their map back from 
the allies (which was taken in cod1)Cheesy i know but thats how I did it 
Compatible with the following maps

mp_farmhouse
mp_brecourt
mp_dawnville
mp_breakout
mp_railyard
mp_leningrad
mp_downtown
mp_matmata

All other maps will not spawn objectives, 
More maps will be added 



Gametype Cvars 

scr_re_roundlength //How long each round is
scr_re_graceperiod //How long you can change weapons and joing the game
scr_re_roundlimit //Round limit - how many rounds are played
scr_re_scorelimit // Score limit - score limit before map ends
scr_re_timelimit // time limit for the entire match 

