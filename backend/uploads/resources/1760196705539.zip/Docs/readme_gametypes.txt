Custom gametypes for Call of Duty 2
Author:  bell
Website: http://awe.milliways.st/

Included are Last Team Standing (LTS) and Hold the Flag (HTF)

See lts.cfg and htf.cfg for available cvars.

Known issues
------------
HTF is not using localized strings and will likely spam your console with complaints about it.


Have fun!
